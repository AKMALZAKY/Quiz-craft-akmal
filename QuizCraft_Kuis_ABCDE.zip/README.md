# QuizCraft — Pembuat & Pengisi Kuis

Aplikasi kuis ABCDE yang dibuat agar mudah dipahami dan bisa dibuka dari HP maupun komputer.

## Fitur

- Mode **Pembuat** dan **Pengisi**
- Pembuat membuat akun sendiri: nama, username, password (tanpa Gmail/Google)
- Membuat bidang pelajaran, judul, deskripsi
- Soal pilihan ganda A–E
- Menentukan jawaban benar dan nilai per soal
- Kode kelas otomatis 6 karakter
- Pengisi memasukkan kode + nama sendiri
- Nilai langsung muncul setelah mengirim
- Pembuat bisa melihat daftar pengisi, nilai, jumlah benar, dan waktu pengisian
- Data disimpan di `data.json`, sehingga dapat dipakai lintas perangkat selama perangkat terhubung ke server yang sama
- Tampilan responsif untuk HP

## Menjalankan di komputer

1. Install Node.js.
2. Buka terminal di folder ini.
3. Jalankan:
   `npm install`
4. Jalankan:
   `npm start`
5. Buka:
   `http://localhost:3000`

## Agar HP lain bisa ikut

Untuk jaringan Wi-Fi/LAN yang sama, cari alamat IP komputer/server (misalnya `192.168.1.10`), lalu buka dari HP:
`http://192.168.1.10:3000`

Agar bisa diakses dari internet oleh siswa di tempat berbeda, deploy folder ini ke layanan hosting Node.js (misalnya Render/Railway/Fly.io) dan gunakan URL hasil deployment.

### Penting untuk keamanan

- Ganti `AUTH_SECRET` di environment production.
- `data.json` berisi data aplikasi. Jangan dipublikasikan ke GitHub.
- Ini adalah starter app, bukan sistem ujian dengan keamanan tingkat bank. Untuk ujian penting, tambahkan HTTPS, rate limiting, backup, dan database produksi.

## Struktur

- `public/index.html` — tampilan aplikasi
- `server.js` — API + penyimpanan
- `package.json` — dependency
- `data.json` — dibuat otomatis saat aplikasi berjalan
